<!DOCTYPE html>
<html>
  <head>

    <title>Mobile Catalog</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

    <header>
      <div class="container">
        
      <a class="home" href="index.php">
        <div id="mobile-logo">
          <h1><span class="highlight">Mobile Catalog</span></h1>
        </div>
        </a>
        
      </div>
    </header>

    <div id="contact-form">
         <div class="container">   

        <h1>LOG IN</h1>
        <form action="login.inc.php" method="POST">
          <input type="text" id="username" name="uname" placeholder="USERNAME" class="field" required/>
          <div>
          <input type="password" id="password" name="password" placeholder="PASSWORD" class="field" required/>
          <br>
          <div class="button-center">
          <button type="submit" class="button_1">LOG IN</button>
        </div>


          </div>
        </form>
      </div>
</div>


      <footer>
      <div class="container">
        <p> Copyright &copy; 2021</p>
		
      </div>
	  
    </footer>

  </body>
</html>