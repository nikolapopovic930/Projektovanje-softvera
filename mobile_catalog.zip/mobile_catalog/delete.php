<?php
include 'db_conn.php';
$id = $_GET['id'];
$sql = "DELETE FROM mobile WHERE mobile_id=$id;";
$result = mysqli_query($conn, $sql);
mysqli_close($conn);
header('Location: index.php');