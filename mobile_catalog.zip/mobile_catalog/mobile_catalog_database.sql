-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.18-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table mobile_catalog.administrator: ~2 rows (approximately)
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
INSERT INTO `administrator` (`administrator_id`, `username`, `password`) VALUES
	(1, 'admin1', '123'),
	(2, 'marko', 'markobg');
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;

-- Dumping data for table mobile_catalog.category: ~2 rows (approximately)
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`category_id`, `name`) VALUES
	(1, 'Smart phone'),
	(2, 'Standard phone');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;

-- Dumping data for table mobile_catalog.comunication_standard: ~4 rows (approximately)
/*!40000 ALTER TABLE `comunication_standard` DISABLE KEYS */;
INSERT INTO `comunication_standard` (`comunication_standard_id`, `name`) VALUES
	(1, '3G'),
	(2, '4G'),
	(3, 'GSM'),
	(4, 'LTE');
/*!40000 ALTER TABLE `comunication_standard` ENABLE KEYS */;

-- Dumping data for table mobile_catalog.mobile: ~6 rows (approximately)
/*!40000 ALTER TABLE `mobile` DISABLE KEYS */;
INSERT INTO `mobile` (`mobile_id`, `brand`, `model_name`, `image_path`, `price`, `operating_system`, `ram`, `internal_memory`, `screen_diagonal`, `battery`, `resolution`, `have_front_camera`, `have_back_camera`, `category_id`) VALUES
	(5, 'Lenovo', 'K12', 'img/lenovo-k12.png', 119, 'Android', 4, 64, 6.5, 5000, '720x1600', 1, 1, 1),
	(32, 'Xiaomi', 'Redme Note 7', 'img/xaomi-redmi-note-7.png', 299, 'Android', 6, 64, 6.3, 4000, '2340x1080', 1, 1, 1),
	(36, 'Huawei', 'P50', 'img/huawei-p50.png', 699, 'Android', 8, 256, 6.3, 4000, '1080x2340', 1, 1, 1),
	(40, 'Samsung', 'Galaxy A51', 'img/samsung-galaxy-a51.png', 245, 'Android', 4, 64, 6.5, 4000, '2400x1080', 1, 1, 1),
	(41, 'HTC', 'Wildfire E3', 'img/htc-wild-fire-e3.png', 129, 'Android', 4, 64, 6.5, 4000, '720x1560', 1, 1, 1),
	(42, 'Apple', 'Iphone X', 'img/iphone-x.jpg', 529, 'IOS', 3, 64, 5.8, 2716, '2436x1125', 1, 1, 1);
/*!40000 ALTER TABLE `mobile` ENABLE KEYS */;

-- Dumping data for table mobile_catalog.mobile_comunication_standard: ~25 rows (approximately)
/*!40000 ALTER TABLE `mobile_comunication_standard` DISABLE KEYS */;
INSERT INTO `mobile_comunication_standard` (`mobile_comunication_standard_id`, `mobile_id`, `comunication_standard_id`) VALUES
	(97, 5, 1),
	(98, 5, 3),
	(99, 5, 4),
	(100, 41, 1),
	(101, 41, 2),
	(102, 41, 3),
	(103, 41, 4),
	(104, 40, 1),
	(105, 40, 2),
	(106, 40, 3),
	(107, 40, 4),
	(108, 32, 1),
	(109, 32, 2),
	(110, 32, 3),
	(111, 32, 4),
	(112, 42, 1),
	(113, 42, 2),
	(114, 42, 3),
	(115, 42, 4),
	(116, 36, 1),
	(117, 36, 2),
	(118, 36, 3),
	(119, 36, 4);
/*!40000 ALTER TABLE `mobile_comunication_standard` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
